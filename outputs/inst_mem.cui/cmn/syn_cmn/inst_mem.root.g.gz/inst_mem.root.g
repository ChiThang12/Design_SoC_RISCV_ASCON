######################################################################

# Created by Genus(TM) Synthesis Solution 23.10-p004_1 on Fri Feb 13 19:36:10 +07 2026

# This file contains the Genus script for design:inst_mem

######################################################################

set_db -quiet information_level 7
set_db -quiet init_lib_search_path {$absolute_libaries_path}
set_db -quiet design_mode_process 160.0
set_db -quiet phys_assume_met_fill 0.0
set_db -quiet map_placed_for_route_early_global false
set_db -quiet phys_use_invs_extraction true
set_db -quiet phys_route_time_out 120.0
set_db -quiet capacitance_per_unit_length_mmmc {}
set_db -quiet resistance_per_unit_length_mmmc {}
set_db -quiet runtime_by_stage {{PBS_Generic-Start 0 128 0.0 33.970645} {to_generic 7 135 5 40} {first_condense 1 136 0 41} {PBS_Generic_Opt-Post 9 137 7.542646000000005 41.513291} {{PBS_Generic-Postgen HBO Optimizations} 0 137 1.0 42.513291} {PBS_TechMap-Start 0 214 0.0 49.440445} {{PBS_TechMap-Premap HBO Optimizations} 0 214 0.0 49.440445} {second_condense 1 215 1 52} {reify 1 216 2 54} {global_incr_map 1 217 1 55} {{PBS_Techmap-Global Mapping} 4 218 4.447185000000005 53.88763} {{PBS_TechMap-Datapath Postmap Operations} 3 221 3.0 56.88763} {{PBS_TechMap-Postmap HBO Optimizations} 0 221 -0.007710000000002992 56.87992} {{PBS_TechMap-Postmap Clock Gating} 0 221 0.0 56.87992} {{PBS_TechMap-Postmap Cleanup} 1 222 0.9854389999999995 57.865359} {PBS_Techmap-Post_MBCI 0 222 0.0 57.865359} {incr_opt 5 297 4 71} }
set_db -quiet timing_adjust_tns_of_complex_flops false
set_db -quiet timing_report_enable_common_header false
set_db -quiet dft_use_ungated_clock_for_testpoint true
set_db -quiet tinfo_tstamp_file .rs_ducnm.23ce.tstamp
set_db -quiet common_preserve_skip_internal true
set_db -quiet script_search_path {. ./scripts }
set_db -quiet auto_ungroup none
set_db -quiet use_area_from_lef true
set_db -quiet use_scan_seqs_for_non_dft false
set_db -quiet flow_metrics_snapshot_uuid 13c3f7bf-a35f-432b-8646-c1c921652801
set_db -quiet syn_generic_effort high
set_db -quiet inst:inst_mem/u_ram_macro .hdl_instantiated true
# there is no hdl_instantiated attribute information available
set_db -quiet source_verbose true
