######################################################################

# Created by Genus(TM) Synthesis Solution 23.10-p004_1 on Fri Feb 13 19:56:55 +07 2026

# This file contains the Genus script for design:inst_mem

######################################################################

set_db -quiet information_level 7
set_db -quiet init_lib_search_path {$absolute_libaries_path}
set_db -quiet design_mode_process 160.0
set_db -quiet phys_assume_met_fill 0.0
set_db -quiet map_placed_for_route_early_global false
set_db -quiet phys_use_invs_extraction true
set_db -quiet phys_route_time_out 120.0
set_db -quiet capacitance_per_unit_length_mmmc {}
set_db -quiet resistance_per_unit_length_mmmc {}
set_db -quiet runtime_by_stage {{PBS_Generic-Start 0 43 0.0 26.989716} {to_generic 4 47 3 30} {first_condense 1 48 0 32} {PBS_Generic_Opt-Post 5 48 4.502292999999998 31.492009} {{PBS_Generic-Postgen HBO Optimizations} 0 49 0.0 32.492009} {PBS_TechMap-Start 0 52 0.0 34.423162} {{PBS_TechMap-Premap HBO Optimizations} 0 52 0.0 34.423162} {second_condense 1 53 1 37} {reify 1 54 2 39} {global_incr_map 1 55 1 40} {{PBS_Techmap-Global Mapping} 4 56 3.5249120000000005 37.948074} {{PBS_TechMap-Datapath Postmap Operations} 3 59 2.0 40.948074} {{PBS_TechMap-Postmap HBO Optimizations} 0 59 0.9926080000000042 41.940682} {{PBS_TechMap-Postmap Clock Gating} 0 59 0.0 41.940682} {{PBS_TechMap-Postmap Cleanup} 0 59 -0.014090000000003045 41.926592} {PBS_Techmap-Post_MBCI 1 60 0.0 41.926592} {incr_opt 4 67 4 51} }
set_db -quiet timing_adjust_tns_of_complex_flops false
set_db -quiet timing_report_enable_common_header false
set_db -quiet dft_use_ungated_clock_for_testpoint true
set_db -quiet tinfo_tstamp_file .rs_ducnm.23ce.tstamp
set_db -quiet common_preserve_skip_internal true
set_db -quiet script_search_path {. ./scripts }
set_db -quiet auto_ungroup none
set_db -quiet use_area_from_lef true
set_db -quiet use_scan_seqs_for_non_dft false
set_db -quiet flow_metrics_snapshot_uuid 8b64685b-215f-4599-ad77-935aca1383e1
set_db -quiet syn_generic_effort high
set_db -quiet inst:inst_mem/u_ram_macro .hdl_instantiated true
# there is no hdl_instantiated attribute information available
set_db -quiet source_verbose true
