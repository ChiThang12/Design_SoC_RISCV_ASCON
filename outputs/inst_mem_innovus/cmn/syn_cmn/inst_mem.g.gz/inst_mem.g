######################################################################

# Created by Genus(TM) Synthesis Solution 23.10-p004_1 on Fri Feb 13 19:56:54 +07 2026

# This file contains the Genus script for design:inst_mem

######################################################################

set_db -quiet information_level 7
set_db -quiet init_lib_search_path {$absolute_libaries_path}
set_db -quiet design_mode_process 160.0
set_db -quiet phys_assume_met_fill 0.0
set_db -quiet map_placed_for_route_early_global false
set_db -quiet phys_use_invs_extraction true
set_db -quiet phys_route_time_out 120.0
set_db -quiet capacitance_per_unit_length_mmmc {}
set_db -quiet resistance_per_unit_length_mmmc {}
set_db -quiet runtime_by_stage {{PBS_Generic-Start 0 43 0.0 26.989716} {to_generic 4 47 3 30} {first_condense 1 48 0 32} {PBS_Generic_Opt-Post 5 48 4.502292999999998 31.492009} {{PBS_Generic-Postgen HBO Optimizations} 0 49 0.0 32.492009} {PBS_TechMap-Start 0 52 0.0 34.423162} {{PBS_TechMap-Premap HBO Optimizations} 0 52 0.0 34.423162} {second_condense 1 53 1 37} {reify 1 54 2 39} {global_incr_map 1 55 1 40} {{PBS_Techmap-Global Mapping} 4 56 3.5249120000000005 37.948074} {{PBS_TechMap-Datapath Postmap Operations} 3 59 2.0 40.948074} {{PBS_TechMap-Postmap HBO Optimizations} 0 59 0.9926080000000042 41.940682} {{PBS_TechMap-Postmap Clock Gating} 0 59 0.0 41.940682} {{PBS_TechMap-Postmap Cleanup} 0 59 -0.014090000000003045 41.926592} {PBS_Techmap-Post_MBCI 1 60 0.0 41.926592} {incr_opt 4 67 4 51} }
set_db -quiet timing_adjust_tns_of_complex_flops false
set_db -quiet timing_report_enable_common_header false
set_db -quiet dft_use_ungated_clock_for_testpoint true
set_db -quiet tinfo_tstamp_file .rs_ducnm.23ce.tstamp
set_db -quiet common_preserve_skip_internal true
set_db -quiet script_search_path {. ./scripts }
set_db -quiet auto_ungroup none
set_db -quiet use_area_from_lef true
set_db -quiet use_scan_seqs_for_non_dft false
set_db -quiet flow_metrics_snapshot_uuid 8b64685b-215f-4599-ad77-935aca1383e1
set_db -quiet syn_generic_effort high
set_db -quiet phys_use_segment_parasitics true
set_db -quiet probabilistic_extraction true
set_db -quiet ple_correlation_factors {1.9000 2.0000}
set_db -quiet maximum_interval_of_vias inf
set_db -quiet layer_aware_buffer true
set_db -quiet ple_mode global
::legacy::set_attr -quiet ui_respects_preserve 0 /
::legacy::set_attribute -quiet library_domain library_domain:slow design:inst_mem
::legacy::set_attr -quiet ui_respects_preserve true /
# BEGIN MSV SECTION
# END MSV SECTION
# BEGIN DFT SECTION
set_db -quiet dft_scan_style muxed_scan
set_db -quiet dft_scanbit_waveform_analysis false
# END DFT SECTION
set_db -quiet design:inst_mem .seq_reason_deleted_internal {{{current_addr_reg[0]} unloaded {current_addr[0]}} {{current_addr_reg[1]} unloaded {current_addr[1]}} {{current_addr_reg[12]} unloaded {current_addr[12]}} {{current_addr_reg[13]} unloaded {current_addr[13]}} {{current_addr_reg[14]} unloaded {current_addr[14]}} {{current_addr_reg[15]} unloaded {current_addr[15]}} {{current_addr_reg[16]} unloaded {current_addr[16]}} {{current_addr_reg[17]} unloaded {current_addr[17]}} {{current_addr_reg[18]} unloaded {current_addr[18]}} {{current_addr_reg[19]} unloaded {current_addr[19]}} {{current_addr_reg[20]} unloaded {current_addr[20]}} {{current_addr_reg[21]} unloaded {current_addr[21]}} {{current_addr_reg[22]} unloaded {current_addr[22]}} {{current_addr_reg[23]} unloaded {current_addr[23]}} {{current_addr_reg[24]} unloaded {current_addr[24]}} {{current_addr_reg[25]} unloaded {current_addr[25]}} {{current_addr_reg[26]} unloaded {current_addr[26]}} {{current_addr_reg[27]} unloaded {current_addr[27]}} {{current_addr_reg[28]} unloaded {current_addr[28]}} {{current_addr_reg[29]} unloaded {current_addr[29]}} {{current_addr_reg[30]} unloaded {current_addr[30]}} {{current_addr_reg[31]} unloaded {current_addr[31]}} {burst_valid_reg {{merged with burst_state_reg}} burst_valid burst_state}}
set_db -quiet design:inst_mem .qos_by_stage {{to_generic {wns -11111111} {tns -111111111} {vep -111111111} {area 268391} {cell_count 189} {utilization  0.00} {runtime 4 47 3 30} }{first_condense {wns -11111111} {tns -111111111} {vep -111111111} {area 268855} {cell_count 263} {utilization  0.00} {runtime 1 48 0 32} }{second_condense {wns -11111111} {tns -111111111} {vep -111111111} {area 268844} {cell_count 261} {utilization  0.00} {runtime 1 53 1 37} }{reify {wns 493} {tns 0} {vep 0} {area 269144} {cell_count 207} {utilization  0.00} {runtime 1 54 2 39} }{global_incr_map {wns 493} {tns 0} {vep 0} {area 269104} {cell_count 210} {utilization  0.00} {runtime 1 55 1 40} }{incr_opt {wns 214748365} {tns 0} {vep 0} {area 269546} {cell_count 234} {utilization  0.00} {runtime 4 67 4 51} }}
set_db -quiet design:inst_mem .seq_mbci_coverage 0.0
set_db -quiet design:inst_mem .stylus_db_state mapped
set_db -quiet design:inst_mem .hdl_filelist {{default -v2001 {SYNTHESIS} {rtl/inst_mem.v} {$absolute_rtl_path} {}}}
set_db -quiet design:inst_mem .hdl_user_name inst_mem
set_db -quiet design:inst_mem .verification_directory fv/inst_mem
set_db -quiet design:inst_mem .seq_reason_deleted {{{current_addr_reg[0]} unloaded} {{current_addr_reg[1]} unloaded} {{current_addr_reg[12]} unloaded} {{current_addr_reg[13]} unloaded} {{current_addr_reg[14]} unloaded} {{current_addr_reg[15]} unloaded} {{current_addr_reg[16]} unloaded} {{current_addr_reg[17]} unloaded} {{current_addr_reg[18]} unloaded} {{current_addr_reg[19]} unloaded} {{current_addr_reg[20]} unloaded} {{current_addr_reg[21]} unloaded} {{current_addr_reg[22]} unloaded} {{current_addr_reg[23]} unloaded} {{current_addr_reg[24]} unloaded} {{current_addr_reg[25]} unloaded} {{current_addr_reg[26]} unloaded} {{current_addr_reg[27]} unloaded} {{current_addr_reg[28]} unloaded} {{current_addr_reg[29]} unloaded} {{current_addr_reg[30]} unloaded} {{current_addr_reg[31]} unloaded} {burst_valid_reg {{merged with burst_state_reg}}}}
set_db -quiet design:inst_mem .sdc_time_unit 1000.0
set_db -quiet design:inst_mem .sdc_load_unit 1000.0
set_db -quiet design:inst_mem .arch_filename ././rtl/inst_mem.v
set_db -quiet design:inst_mem .entity_filename ././rtl/inst_mem.v
set_db -quiet inst:inst_mem/burst_last_reg .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/beat_count_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/beat_count_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/beat_count_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/beat_count_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/beat_count_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[30]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/current_addr_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[21]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[22]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[23]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[24]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[25]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[26]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[27]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[28]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[29]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/current_addr_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[31]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/current_addr_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/current_addr_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/current_addr_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/beat_count_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/beat_count_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/beat_count_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/current_addr_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/current_addr_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/current_addr_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[9]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[10]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[11]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[12]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/current_addr_reg[8]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[14]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[15]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[16]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[17]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[18]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[19]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[20]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[13]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/burst_data_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/total_beats_reg[6]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/total_beats_reg[3]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/total_beats_reg[4]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/total_beats_reg[5]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/total_beats_reg[2]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/total_beats_reg[7]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/total_beats_reg[0]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/total_beats_reg[1]} .orig_hdl_instantiated false
set_db -quiet {inst:inst_mem/current_addr_reg[2]} .orig_hdl_instantiated false
set_db -quiet inst:inst_mem/burst_state_reg .orig_hdl_instantiated false
# BEGIN PMBIST SECTION
# END PMBIST SECTION
# BEGIN PHYSICAL ANNOTATION SECTION
# END PHYSICAL ANNOTATION SECTION
set_db -quiet inst:inst_mem/u_ram_macro .hdl_instantiated true
# there is no hdl_instantiated attribute information available
set_db -quiet source_verbose true
