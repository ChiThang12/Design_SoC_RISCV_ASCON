// ============================================================================
// Module: icache_axi_interface  (v3 — pure wire pass-through)
// ============================================================================
// Controller drives AXI directly (m_axi_arvalid, m_axi_araddr are registers).
// This module is a transparent bridge to external mem_* ports.
// Zero registers on any signal path.
// ============================================================================

`include "cpu/interface/icache/icache_defines.vh"

module icache_axi_interface (
    input  wire        clk,
    input  wire        rst_n,

    // From controller
    input  wire [31:0] m_axi_araddr,
    input  wire        m_axi_arvalid,
    input  wire [ 7:0] m_axi_arlen,
    input  wire [ 2:0] m_axi_arsize,
    input  wire [ 1:0] m_axi_arburst,
    input  wire [ 2:0] m_axi_arprot,
    output wire        m_axi_arready,

    output wire [31:0] m_axi_rdata,
    output wire        m_axi_rvalid,
    output wire        m_axi_rlast,
    input  wire        m_axi_rready,

    // External memory
    output wire [31:0] M_AXI_ARADDR,
    output wire [ 7:0] M_AXI_ARLEN,
    output wire [ 2:0] M_AXI_ARSIZE,
    output wire [ 1:0] M_AXI_ARBURST,
    output wire [ 2:0] M_AXI_ARPROT,
    output wire        M_AXI_ARVALID,
    input  wire        M_AXI_ARREADY,

    input  wire [31:0] M_AXI_RDATA,
    input  wire [ 1:0] M_AXI_RRESP,
    input  wire        M_AXI_RLAST,
    input  wire        M_AXI_RVALID,
    output wire        M_AXI_RREADY
);
    assign M_AXI_ARADDR  = m_axi_araddr;
    assign M_AXI_ARLEN   = m_axi_arlen;
    assign M_AXI_ARSIZE  = m_axi_arsize;
    assign M_AXI_ARBURST = m_axi_arburst;
    assign M_AXI_ARPROT  = m_axi_arprot;
    assign M_AXI_ARVALID = m_axi_arvalid;
    assign m_axi_arready = M_AXI_ARREADY;

    assign m_axi_rdata   = M_AXI_RDATA;
    assign m_axi_rvalid  = M_AXI_RVALID;
    assign m_axi_rlast   = M_AXI_RLAST;
    assign M_AXI_RREADY  = m_axi_rready;
endmodule
