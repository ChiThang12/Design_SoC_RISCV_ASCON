// ============================================================================
// Module: icache_controller  (v10 — Dual-Outstanding AR, True CPI=1)
// ============================================================================
//
// NGUYÊN LÝ ĐẠT CPI=1:
// ─────────────────────
//  Khi CPU đang consume line K (tối đa 4 cycles), cache phải fetch XONG line K+1.
//  Với AXI_lat=L và 4 beats/line:  fetch time = L + 4 cycles.
//
//  Nếu L=1: fetch = 5 cycles. CPU consume = 4 cycles. → line K+1 chậm hơn 1 cycle!
//  → Cần gửi AR line K+1 TRƯỚC KHI xong beat0 của line K.
//
//  GIẢI PHÁP: 2 OUTSTANDING AR
//  ─────────────────────────────
//  Sau khi AR line K được accept (arready=1 tại C1):
//    → Ngay tại C1: issue AR line K+1.
//
//  Timeline (AXI_lat=1):
//    C0 : miss → AR line0
//    C1 : AR line0 accepted → AR line1 issued immediately
//         R line0 beat0 starts arriving
//    C2 : beat0 line0 → cpu_ready (cw=0, PC=0)
//         R line1 beat0 starts arriving (AXI_lat=1 from C1)
//    C3 : beat1 line0; beat0 line1 written
//    C4 : beat2 line0; beat1 line1
//    C5 : beat3 line0 RLAST → ctrl_valid[0]=1
//         beat2 line1
//    C6 : beat3 line1 RLAST → ctrl_valid[1]=1    ← line1 ready at C6!
//    C6 : PC=4  HIT (ctrl_valid[0] since C5)     ← 1 cycle
//    C7 : PC=8  HIT                              ← 1 cycle
//    C8 : PC=12 HIT; issue AR line2              ← 1 cycle
//    C9 : PC=16 → ctrl_valid[1]=1 (since C6) → HIT! ← ZERO STALL
//
//  Để handle 2 outstanding bursts, cần:
//  1. AR FIFO (depth=2): ar_slot[0] = active, ar_slot[1] = pending
//  2. R de-mux: beat 0..3 đầu tiên → line0 buffer; 4..7 → line1 buffer
//     → Dùng burst_id FIFO (depth=2) để biết beat này của line nào
//
// IMPLEMENTATION:
// ───────────────
//  - ar_q[2]: FIFO lưu {addr, index, tag, is_pf}
//    ar_head: hiện đang được issue
//    ar_tail: slot trống kế tiếp
//  - R burst de-mux: r_q[2] same structure
//    r_head: burst đang nhận beats
//    Khi RLAST: advance r_head
//
// ============================================================================

`include "cpu/interface/icache/icache_defines.vh"

module icache_controller (
    input  wire        clk,
    input  wire        rst_n,

    // ── CPU Interface ────────────────────────────────────────────────────────
    input  wire [31:0] cpu_addr,
    input  wire        cpu_req,
    output wire [31:0] cpu_rdata,
    output wire        cpu_ready,
    input  wire        flush,

    // ── Tag Array Interface ──────────────────────────────────────────────────
    output wire [ 5:0] tag_lookup_index,
    output wire [21:0] tag_lookup_tag,
    input  wire        tag_hit,
    output reg         tag_update_valid,
    output reg  [ 5:0] tag_update_index,
    output reg  [21:0] tag_update_tag,
    output reg         tag_flush_all,

    // ── Data Array Interface ─────────────────────────────────────────────────
    output wire [ 5:0] data_read_index,
    output wire [ 1:0] data_read_offset,
    input  wire [31:0] data_read_data,
    output reg         data_write_enable,
    output reg  [ 5:0] data_write_index,
    output reg  [ 1:0] data_write_offset,
    output reg  [31:0] data_write_data,

    // ── AXI AR Channel ───────────────────────────────────────────────────────
    output reg  [31:0] m_axi_araddr,
    output reg         m_axi_arvalid,
    output wire [ 7:0] m_axi_arlen,
    output wire [ 2:0] m_axi_arsize,
    output wire [ 1:0] m_axi_arburst,
    output wire [ 2:0] m_axi_arprot,
    input  wire        m_axi_arready,

    // ── AXI R Channel ────────────────────────────────────────────────────────
    input  wire [31:0] m_axi_rdata,
    input  wire        m_axi_rvalid,
    input  wire        m_axi_rlast,
    output wire        m_axi_rready,

    // ── Statistics ───────────────────────────────────────────────────────────
    output reg  [31:0] stat_hits,
    output reg  [31:0] stat_misses
);

    assign m_axi_arlen   = 8'd3;
    assign m_axi_arsize  = 3'b010;
    assign m_axi_arburst = 2'b01;
    assign m_axi_arprot  = 3'b000;
    assign m_axi_rready  = 1'b1;

    // =========================================================================
    // Address decomposition
    // =========================================================================
    wire [21:0] cpu_tag    = cpu_addr[31:10];
    wire [ 5:0] cpu_index  = cpu_addr[9:4];
    wire [ 1:0] cpu_offset = cpu_addr[3:2];

    wire [31:0] nl_base  = {cpu_addr[31:4], 4'b0} + 32'd16;
    wire [ 5:0] nl_index = nl_base[9:4];
    wire [21:0] nl_tag   = nl_base[31:10];

    // =========================================================================
    // Internal valid/tag (combinational hit)
    // =========================================================================
    reg        ctrl_valid [0:63];
    reg [21:0] ctrl_tag   [0:63];

    wire ctrl_hit   = ctrl_valid[cpu_index] && (ctrl_tag[cpu_index] == cpu_tag);
    wire nl_cached  = ctrl_valid[nl_index]  && (ctrl_tag[nl_index]  == nl_tag);

    assign tag_lookup_index = cpu_index;
    assign tag_lookup_tag   = cpu_tag;
    assign data_read_index  = cpu_index;
    assign data_read_offset = cpu_offset;

    // =========================================================================
    // AR Queue (depth=2 for dual-outstanding)
    // =========================================================================
    // Slot 0 = currently being issued / waiting for arready
    // Slot 1 = next to issue after slot 0 accepted
    reg        arq_valid [0:1];
    reg [31:0] arq_addr  [0:1];
    reg [ 5:0] arq_index [0:1];
    reg [21:0] arq_tag   [0:1];
    reg        arq_is_pf [0:1];   // 0=demand, 1=prefetch

    wire arq_full  = arq_valid[0] && arq_valid[1];
    wire arq_empty = !arq_valid[0];

    // =========================================================================
    // R Queue (mirrors AR queue: tracks which line each burst fills)
    // =========================================================================
    // rq_head = currently receiving beats
    reg [ 5:0] rq_index [0:1];
    reg [21:0] rq_tag   [0:1];
    reg        rq_is_pf [0:1];
    reg        rq_valid [0:1];
    reg [ 1:0] rq_head;          // 0 or 1: which slot is currently receiving
    reg [ 1:0] burst_beat;       // beat counter within current burst

    // =========================================================================
    // Demand miss context
    // =========================================================================
    reg [ 5:0] d_index;
    reg [ 1:0] d_offset;
    reg        d_served;

    // =========================================================================
    // FSM
    // =========================================================================
    localparam S_COMPARE = 1'b0;
    localparam S_DEMAND  = 1'b1;

    reg state, next_state;

    always @(posedge clk or negedge rst_n) begin
        if      (!rst_n) state <= S_COMPARE;
        else if (flush)  state <= S_COMPARE;
        else             state <= next_state;
    end

    always @(*) begin
        next_state = state;
        case (state)
            S_COMPARE: if (cpu_req && !ctrl_hit) next_state = S_DEMAND;
            S_DEMAND:  if (ctrl_hit)             next_state = S_COMPARE;
        endcase
    end

    // =========================================================================
    // cpu_ready — combinational
    // =========================================================================
    // Current R burst head info
    wire [ 5:0] r_cur_index = rq_index[rq_head[0]];
    wire        r_cur_is_pf = rq_is_pf[rq_head[0]];

    // Critical-word match: demand burst, correct beat
    wire cw_ready = (state == S_DEMAND)
                  && m_axi_rvalid
                  && !r_cur_is_pf
                  && (burst_beat == d_offset)
                  && !d_served;

    assign cpu_ready = (state == S_COMPARE && cpu_req && ctrl_hit) || cw_ready;
    assign cpu_rdata = cw_ready ? m_axi_rdata : data_read_data;

    // =========================================================================
    // Helper: enqueue into AR queue (task-like macro via always block)
    // Caller uses inline assignments into arq_*
    // =========================================================================

    // =========================================================================
    // Sequential Logic
    // =========================================================================
    integer i;

    // Temporary next-state for AR queue (Verilog-style)
    reg [31:0] t_araddr;
    reg [ 5:0] t_arindex;
    reg [21:0] t_artag;
    reg        t_ar_is_pf;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            m_axi_arvalid   <= 1'b0;
            m_axi_araddr    <= 32'h0;
            arq_valid[0]    <= 1'b0; arq_valid[1]    <= 1'b0;
            arq_addr[0]     <= 32'h0; arq_addr[1]    <= 32'h0;
            arq_index[0]    <= 6'h0; arq_index[1]    <= 6'h0;
            arq_tag[0]      <= 22'h0; arq_tag[1]     <= 22'h0;
            arq_is_pf[0]    <= 1'b0; arq_is_pf[1]   <= 1'b0;
            rq_valid[0]     <= 1'b0; rq_valid[1]     <= 1'b0;
            rq_index[0]     <= 6'h0; rq_index[1]     <= 6'h0;
            rq_tag[0]       <= 22'h0; rq_tag[1]      <= 22'h0;
            rq_is_pf[0]     <= 1'b0; rq_is_pf[1]    <= 1'b0;
            rq_head         <= 2'b0;
            burst_beat      <= 2'b0;
            d_index         <= 6'h0;
            d_offset        <= 2'b0;
            d_served        <= 1'b0;
            data_write_enable<= 1'b0;
            data_write_index <= 6'h0;
            data_write_offset<= 2'b0;
            data_write_data  <= 32'h0;
            tag_update_valid <= 1'b0;
            tag_update_index <= 6'h0;
            tag_update_tag   <= 22'h0;
            tag_flush_all    <= 1'b0;
            stat_hits        <= 32'h0;
            stat_misses      <= 32'h0;
            for (i = 0; i < 64; i = i + 1) begin
                ctrl_valid[i] <= 1'b0;
                ctrl_tag[i]   <= 22'h0;
            end
        end else begin
            data_write_enable <= 1'b0;
            tag_update_valid  <= 1'b0;
            tag_flush_all     <= 1'b0;

            // ── Flush ─────────────────────────────────────────────────────────
            if (flush) begin
                m_axi_arvalid <= 1'b0;
                arq_valid[0]  <= 1'b0;
                arq_valid[1]  <= 1'b0;
                rq_valid[0]   <= 1'b0;
                rq_valid[1]   <= 1'b0;
                rq_head       <= 2'b0;
                burst_beat    <= 2'b0;
                d_served      <= 1'b0;
                tag_flush_all <= 1'b1;
                for (i = 0; i < 64; i = i + 1)
                    ctrl_valid[i] <= 1'b0;

            end else begin

                // ==============================================================
                // [A] AR ISSUE — drive ARVALID from queue slot 0
                // ==============================================================
                if (!m_axi_arvalid && arq_valid[0]) begin
                    // Issue slot 0
                    m_axi_arvalid <= 1'b1;
                    m_axi_araddr  <= arq_addr[0];
                end

                // AR handshake: slot 0 accepted → slide queue, push to R queue
                if (m_axi_arvalid && m_axi_arready) begin
                    m_axi_arvalid <= 1'b0;

                    // Push into R queue (next available R slot)
                    // R slots are consumed in-order (FIFO), find next empty
                    // Since max 2 outstanding, one of rq[0..1] is free
                    if (!rq_valid[0]) begin
                        rq_valid[0]  <= 1'b1;
                        rq_index[0]  <= arq_index[0];
                        rq_tag[0]    <= arq_tag[0];
                        rq_is_pf[0]  <= arq_is_pf[0];
                    end else begin
                        rq_valid[1]  <= 1'b1;
                        rq_index[1]  <= arq_index[0];
                        rq_tag[1]    <= arq_tag[0];
                        rq_is_pf[1]  <= arq_is_pf[0];
                    end

                    // Slide AR queue: slot1 → slot0
                    arq_valid[0] <= arq_valid[1];
                    arq_addr[0]  <= arq_addr[1];
                    arq_index[0] <= arq_index[1];
                    arq_tag[0]   <= arq_tag[1];
                    arq_is_pf[0] <= arq_is_pf[1];
                    arq_valid[1] <= 1'b0;
                end

                // ==============================================================
                // [B] R CHANNEL — write beats, validate line on RLAST
                // ==============================================================
                if (m_axi_rvalid && rq_valid[rq_head[0]]) begin
                    data_write_enable <= 1'b1;
                    data_write_index  <= rq_index[rq_head[0]];
                    data_write_offset <= burst_beat;
                    data_write_data   <= m_axi_rdata;
                    burst_beat        <= burst_beat + 1;

                    // Critical word tracking
                    if (!rq_is_pf[rq_head[0]] && burst_beat == d_offset)
                        d_served <= 1'b1;

                    if (m_axi_rlast) begin
                        // Validate the completed line
                        ctrl_valid[rq_index[rq_head[0]]] <= 1'b1;
                        ctrl_tag[rq_index[rq_head[0]]]   <= rq_tag[rq_head[0]];
                        tag_update_valid  <= 1'b1;
                        tag_update_index  <= rq_index[rq_head[0]];
                        tag_update_tag    <= rq_tag[rq_head[0]];

                        // Release R slot and advance head
                        rq_valid[rq_head[0]] <= 1'b0;
                        rq_head    <= rq_head + 1;  // toggles 0↔1
                        burst_beat <= 2'b0;
                        d_served   <= 1'b0;
                    end
                end

                // ==============================================================
                // [C] S_COMPARE — serve CPU, manage prefetch requests
                // ==============================================================
                if (state == S_COMPARE && cpu_req) begin
                    if (ctrl_hit) begin
                        stat_hits <= stat_hits + 1;

                        // Prefetch next line when CPU is at offset 0 or 1
                        // Goal: issue AR early enough that data arrives before CPU needs it
                        if (!nl_cached && cpu_offset <= 2'b01 && !arq_full) begin
                            // Check this line isn't already queued
                            if (!(arq_valid[0] && arq_index[0]==nl_index) &&
                                !(arq_valid[1] && arq_index[1]==nl_index) &&
                                !(rq_valid[0]  && rq_index[0] ==nl_index) &&
                                !(rq_valid[1]  && rq_index[1] ==nl_index)) begin
                                // Enqueue prefetch
                                if (!arq_valid[0]) begin
                                    arq_valid[0] <= 1'b1;
                                    arq_addr[0]  <= {nl_base[31:4], 4'b0};
                                    arq_index[0] <= nl_index;
                                    arq_tag[0]   <= nl_tag;
                                    arq_is_pf[0] <= 1'b1;
                                end else begin
                                    arq_valid[1] <= 1'b1;
                                    arq_addr[1]  <= {nl_base[31:4], 4'b0};
                                    arq_index[1] <= nl_index;
                                    arq_tag[1]   <= nl_tag;
                                    arq_is_pf[1] <= 1'b1;
                                end
                            end
                        end

                    end else begin
                        // ── DEMAND MISS ───────────────────────────────────────
                        stat_misses <= stat_misses + 1;
                        d_index     <= cpu_index;
                        d_offset    <= cpu_offset;
                        d_served    <= 1'b0;

                        // Cancel any queued prefetches (demand has priority)
                        // Only cancel slot1 (slot0 may be active/being issued)
                        if (arq_valid[1] && arq_is_pf[1])
                            arq_valid[1] <= 1'b0;

                        // Enqueue demand miss at front (slot0 if free, else slot1)
                        if (!arq_valid[0]) begin
                            arq_valid[0] <= 1'b1;
                            arq_addr[0]  <= {cpu_addr[31:4], 4'b0};
                            arq_index[0] <= cpu_index;
                            arq_tag[0]   <= cpu_tag;
                            arq_is_pf[0] <= 1'b0;
                        end else if (!arq_valid[1]) begin
                            arq_valid[1] <= 1'b1;
                            arq_addr[1]  <= {cpu_addr[31:4], 4'b0};
                            arq_index[1] <= cpu_index;
                            arq_tag[1]   <= cpu_tag;
                            arq_is_pf[1] <= 1'b0;
                        end

                        // IMMEDIATELY also queue next-line prefetch after demand
                        // (demand at slot0, prefetch at slot1)
                        // This achieves the dual-outstanding for zero stall
                        if (!arq_valid[1]) begin
                            arq_valid[1] <= 1'b1;
                            arq_addr[1]  <= {nl_base[31:4], 4'b0};
                            arq_index[1] <= nl_index;
                            arq_tag[1]   <= nl_tag;
                            arq_is_pf[1] <= 1'b1;
                        end
                    end
                end

            end // !flush
        end // !rst_n
    end

endmodule
