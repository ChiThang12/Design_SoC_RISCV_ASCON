// ============================================================================
// Module: icache_top  (v3 — external interface identical to original)
// ============================================================================

`include "cpu/interface/icache/icache_defines.vh"
`include "cpu/interface/icache/icache_tag_array.v"
`include "cpu/interface/icache/icache_data_array.v"
`include "cpu/interface/icache/icache_axi_interface.v"
`include "cpu/interface/icache/icache_controller.v"

module icache_top #(
    parameter CACHE_SIZE = `ICACHE_SIZE,
    parameter LINE_SIZE  = `ICACHE_LINE_SIZE,
    parameter ADDR_WIDTH = `ICACHE_ADDR_WIDTH,
    parameter DATA_WIDTH = `ICACHE_DATA_WIDTH
)(
    input  wire                  clk,
    input  wire                  rst_n,

    // CPU
    input  wire [ADDR_WIDTH-1:0] cpu_addr,
    input  wire                  cpu_req,
    output wire [DATA_WIDTH-1:0] cpu_rdata,
    output wire                  cpu_ready,
    input  wire                  flush,

    // AXI4 Read
    output wire [ADDR_WIDTH-1:0] mem_araddr,
    output wire [7:0]            mem_arlen,
    output wire [2:0]            mem_arsize,
    output wire [1:0]            mem_arburst,
    output wire [2:0]            mem_arprot,
    output wire                  mem_arvalid,
    input  wire                  mem_arready,

    input  wire [DATA_WIDTH-1:0] mem_rdata,
    input  wire [1:0]            mem_rresp,
    input  wire                  mem_rlast,
    input  wire                  mem_rvalid,
    output wire                  mem_rready,

    // AXI4 Write (tied off — read-only cache)
    output wire [ADDR_WIDTH-1:0] mem_awaddr,
    output wire [7:0]            mem_awlen,
    output wire [2:0]            mem_awsize,
    output wire [1:0]            mem_awburst,
    output wire [2:0]            mem_awprot,
    output wire                  mem_awvalid,
    input  wire                  mem_awready,
    output wire [DATA_WIDTH-1:0] mem_wdata,
    output wire [3:0]            mem_wstrb,
    output wire                  mem_wlast,
    output wire                  mem_wvalid,
    input  wire                  mem_wready,
    input  wire [1:0]            mem_bresp,
    input  wire                  mem_bvalid,
    output wire                  mem_bready,

    // Debug / statistics
    output wire [31:0]           stat_hits,
    output wire [31:0]           stat_misses
);

    // Tie off write channels
    assign mem_awaddr=32'h0; assign mem_awlen=8'h0;   assign mem_awsize=3'b0;
    assign mem_awburst=2'b0; assign mem_awprot=3'b0;  assign mem_awvalid=1'b0;
    assign mem_wdata=32'h0;  assign mem_wstrb=4'h0;   assign mem_wlast=1'b0;
    assign mem_wvalid=1'b0;  assign mem_bready=1'b0;

    // ── Tag array ─────────────────────────────────────────────────────────────
    wire [ 5:0] tag_lookup_index;  wire [21:0] tag_lookup_tag;  wire tag_hit;
    wire        tag_update_valid;  wire [ 5:0] tag_update_index;
    wire [21:0] tag_update_tag;    wire        tag_flush_all;

    // ── Data array ────────────────────────────────────────────────────────────
    wire [ 5:0] data_read_index;   wire [ 1:0] data_read_offset;
    wire [31:0] data_read_data;    wire        data_write_enable;
    wire [ 5:0] data_write_index;  wire [ 1:0] data_write_offset;
    wire [31:0] data_write_data;

    // ── AXI internal wires ───────────────────────────────────────────────────
    wire [31:0] c_araddr;  wire c_arvalid; wire [7:0] c_arlen;
    wire [2:0]  c_arsize;  wire [1:0] c_arburst; wire [2:0] c_arprot;
    wire        c_arready;
    wire [31:0] c_rdata;   wire c_rvalid;  wire c_rlast;  wire c_rready;

    // ── Instances ─────────────────────────────────────────────────────────────
    icache_tag_array tag_array_inst (
        .clk(clk), .rst_n(rst_n),
        .lookup_index(tag_lookup_index), .lookup_tag(tag_lookup_tag),
        .hit(tag_hit),
        .update_valid(tag_update_valid), .update_index(tag_update_index),
        .update_tag(tag_update_tag),     .flush_all(tag_flush_all)
    );

    icache_data_array data_array_inst (
        .clk(clk), .rst_n(rst_n),
        .read_index(data_read_index), .read_offset(data_read_offset),
        .read_data(data_read_data),
        .write_enable(data_write_enable), .write_index(data_write_index),
        .write_offset(data_write_offset), .write_data(data_write_data)
    );

    icache_axi_interface axi_if_inst (
        .clk(clk), .rst_n(rst_n),
        .m_axi_araddr(c_araddr),   .m_axi_arvalid(c_arvalid),
        .m_axi_arlen(c_arlen),     .m_axi_arsize(c_arsize),
        .m_axi_arburst(c_arburst), .m_axi_arprot(c_arprot),
        .m_axi_arready(c_arready),
        .m_axi_rdata(c_rdata),     .m_axi_rvalid(c_rvalid),
        .m_axi_rlast(c_rlast),     .m_axi_rready(c_rready),
        .M_AXI_ARADDR(mem_araddr), .M_AXI_ARLEN(mem_arlen),
        .M_AXI_ARSIZE(mem_arsize), .M_AXI_ARBURST(mem_arburst),
        .M_AXI_ARPROT(mem_arprot), .M_AXI_ARVALID(mem_arvalid),
        .M_AXI_ARREADY(mem_arready),
        .M_AXI_RDATA(mem_rdata),   .M_AXI_RRESP(mem_rresp),
        .M_AXI_RLAST(mem_rlast),   .M_AXI_RVALID(mem_rvalid),
        .M_AXI_RREADY(mem_rready)
    );

    icache_controller controller_inst (
        .clk(clk), .rst_n(rst_n),
        .cpu_addr(cpu_addr), .cpu_req(cpu_req),
        .cpu_rdata(cpu_rdata), .cpu_ready(cpu_ready), .flush(flush),
        .tag_lookup_index(tag_lookup_index), .tag_lookup_tag(tag_lookup_tag),
        .tag_hit(tag_hit),
        .tag_update_valid(tag_update_valid), .tag_update_index(tag_update_index),
        .tag_update_tag(tag_update_tag),     .tag_flush_all(tag_flush_all),
        .data_read_index(data_read_index),   .data_read_offset(data_read_offset),
        .data_read_data(data_read_data),
        .data_write_enable(data_write_enable), .data_write_index(data_write_index),
        .data_write_offset(data_write_offset), .data_write_data(data_write_data),
        .m_axi_araddr(c_araddr),   .m_axi_arvalid(c_arvalid),
        .m_axi_arlen(c_arlen),     .m_axi_arsize(c_arsize),
        .m_axi_arburst(c_arburst), .m_axi_arprot(c_arprot),
        .m_axi_arready(c_arready),
        .m_axi_rdata(c_rdata),     .m_axi_rvalid(c_rvalid),
        .m_axi_rlast(c_rlast),     .m_axi_rready(c_rready),
        .stat_hits(stat_hits),     .stat_misses(stat_misses)
    );

endmodule
